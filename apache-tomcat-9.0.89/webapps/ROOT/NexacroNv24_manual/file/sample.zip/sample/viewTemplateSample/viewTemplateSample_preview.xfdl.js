(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("Form_Work");
            this.set_titletext("Form_Work");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new View("View00","10","10","300","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("View00");
            obj._setViewDataset("viewdataset");
            this.addChild(obj.name, obj);

            obj = new View("View01","10","65","300","100",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("View01");
            obj._setViewDataset("viewdataset");
            this.addChild(obj.name, obj);

            obj = new View("View02","10","175","300","80",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("View02");
            obj._setViewDataset("viewdataset");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","Desktop_screen",1280,720,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script

        
        // Regist UI Components Event
        this.on_initEvent = function()
        {

        };
        this.loadIncludeScript("viewTemplateSample.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
